<?php
/**
 * Khrung Thep child theme: Thai restaurant & matcha cafe, ordered like a shop.
 * The menu is WooCommerce products. Protein and wing size are variations (they change the price);
 * spice (1–5), extras, sweetness and milk are options stored on the cart line and priced here.
 * Orders go to delivery or kerbside pickup at checkout, or straight to WhatsApp.
 */

const KT_WHATSAPP = '254742093080';
const KT_PHONE    = '0742 093080';
const KT_TEL      = '+254742093080';
const KT_IG       = 'https://www.instagram.com/khrungthep.nbo/';
const KT_UBER     = 'https://www.ubereats.com/ke/store/khrung-thep-thai/6tCPZaQfVg-KVWZYWL4ewQ';
const KT_MAPS     = 'https://www.google.com/maps/search/?api=1&query=Khrung+Thep+Thai+Restaurant+%26+Matcha+Cafe&query_place_id=ChIJt-JUUAAXLxgRlhI9mUQ1dUg';
const KT_ADDRESS  = '208 Sports Rd, Westlands, Nairobi (PQPV+JR3)';
const KT_FONTS    = 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=DM+Sans:wght@400;500;600;700&family=Noto+Sans+Thai:wght@400;600&display=swap';

// Opening hours (PLACEHOLDER: Google shows "closes 10 PM"; Uber Eats delivers later on some nights).
const KT_OPEN  = '10:00';
const KT_CLOSE = '22:00';

// Priced options, from their Uber Eats menu (rice, sauce). Milk swaps are a PLACEHOLDER price.
const KT_EXTRAS = [ 'rice' => [ 'Extra white rice', 200 ], 'sauce' => [ 'Extra sauce', 50 ] ];
const KT_MILK   = [ 'regular' => [ 'Regular milk', 0 ], 'oat' => [ 'Oat milk', 100 ], 'coconut' => [ 'Coconut milk', 100 ] ];
const KT_SWEET  = [ 'none' => 'No sugar', 'less' => 'Less sweet', 'regular' => 'Regular', 'extra' => 'Extra sweet' ];
const KT_SPICE  = [ 1 => 'Mild', 2 => 'Gentle', 3 => 'Medium', 4 => 'Hot', 5 => 'Thai hot' ];
const KT_DIETS  = [ 'vegetarian' => 'Vegetarian', 'vegan' => 'Vegan', 'gluten-free' => 'Gluten-free', 'seafood' => 'Seafood', 'chicken' => 'Chicken', 'beef' => 'Beef' ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'kt-fonts', KT_FONTS, [], null );
	wp_enqueue_style( 'kt', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'kt', $uri . '/assets/kt.js', [], filemtime( $dir . '/assets/kt.js' ), true );
	wp_localize_script( 'kt', 'KT', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'api'      => esc_url_raw( rest_url( 'kt/v1/' ) ),
		'shop'     => esc_url_raw( home_url( '/menu/' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => KT_WHATSAPP,
		'maps'     => KT_MAPS,
		'address'  => KT_ADDRESS,
		'open'     => KT_OPEN,
		'close'    => KT_CLOSE,
		'clips'    => $uri . '/assets/clips/',
		'menu'     => is_cart() || is_checkout() ? [] : kt_menu_data(),
		'opts'     => [ 'extras' => KT_EXTRAS, 'milk' => KT_MILK, 'sweet' => KT_SWEET, 'spice' => KT_SPICE ],
	] );
} );

add_action( 'enqueue_block_editor_assets', fn() => wp_enqueue_style( 'kt-fonts', KT_FONTS, [], null ) );
add_action( 'after_setup_theme', fn() => add_editor_style( 'style.css' ) );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function kt_wa_link( $text = '' ) {
	return 'https://wa.me/' . KT_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}
function kt_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}
function kt_lines( $product_id, $key ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_kt_' . $key, true ) ) ) ) );
}
function kt_opts( $product_id ) {
	return array_values( array_filter( explode( ',', (string) get_post_meta( $product_id, '_kt_opts', true ) ) ) );
}
function kt_chillies( $n, $of = 0 ) {
	$h = '<span class="kt-chilli" aria-label="' . esc_attr( $n ? KT_SPICE[ max( 1, min( 5, $n ) ) ] ?? '' : 'Not spicy' ) . '">';
	for ( $i = 1; $i <= max( $n, $of ); $i++ ) {
		$h .= '<i' . ( $i > $n ? ' class="is-off"' : '' ) . '></i>';
	}
	return $h . '</span>';
}

const KT_WA_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/* -------------------------------------------------------------------------
 * Menu data (one list for the menu grid, the dish pop-up and the cart)
 * ---------------------------------------------------------------------- */

function kt_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

function kt_menu_data() {
	static $out = null;
	if ( $out !== null ) {
		return $out;
	}
	$out      = [];
	$products = wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] );
	foreach ( $products as $p ) {
		$id   = $p->get_id();
		$cats = get_the_terms( $id, 'product_cat' ) ?: [];
		$imgs = [];
		foreach ( array_merge( [ $p->get_image_id() ], $p->get_gallery_image_ids() ) as $aid ) {
			$src = $aid ? wp_get_attachment_image_url( $aid, 'woocommerce_single' ) : '';
			if ( $src ) $imgs[] = $src;
		}
		$choices = [];
		$label   = '';
		if ( $p->is_type( 'variable' ) ) {
			foreach ( $p->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( ! $v || ! $v->is_purchasable() ) continue;
				$a         = $v->get_attributes();
				$choices[] = [ 'id' => $vid, 'label' => (string) reset( $a ), 'price' => (float) $v->get_price() ];
			}
			$attrs = $p->get_attributes();
			$label = $attrs ? wc_attribute_label( reset( $attrs )->get_name(), $p ) : '';
		}
		$clip = get_post_meta( $id, '_kt_clip', true );
		$out[ $id ] = [
			'id'        => $id,
			'name'      => $p->get_name(),
			'thai'      => get_post_meta( $id, '_kt_thai', true ),
			'roman'     => get_post_meta( $id, '_kt_roman', true ),
			'cat'       => $cats ? $cats[0]->slug : '',
			'catName'   => $cats ? html_entity_decode( $cats[0]->name ) : '',
			'price'     => $choices ? min( array_column( $choices, 'price' ) ) : (float) $p->get_price(),
			'choices'   => $choices,
			'choice'    => $label,
			'opts'      => kt_opts( $id ),
			'heat'      => (int) get_post_meta( $id, '_kt_heat', true ),
			'tags'      => wp_get_post_terms( $id, 'product_tag', [ 'fields' => 'slugs' ] ),
			'short'     => wp_strip_all_tags( $p->get_short_description() ),
			'portion'   => get_post_meta( $id, '_kt_portion', true ),
			'ingr'      => kt_lines( $id, 'ingredients' ),
			'allergens' => kt_lines( $id, 'allergens' ),
			'veganNote' => get_post_meta( $id, '_kt_vegan_note', true ),
			'badge'     => get_post_meta( $id, '_kt_badge', true ),
			'likes'     => get_post_meta( $id, '_kt_likes', true ),
			'clip'      => $clip ? get_stylesheet_directory_uri() . '/assets/clips/' . $clip . '.mp4' : '',
			'reel'      => get_post_meta( $id, '_kt_reel', true ),
			'drawn'     => get_post_meta( $id, '_kt_drawn', true ) === 'yes',
			'imgs'      => $imgs,
			'url'       => get_permalink( $id ),
			'featured'  => $p->is_featured(),
			'order'     => $p->get_menu_order(),
		];
	}
	return $out;
}

/* -------------------------------------------------------------------------
 * Menu grid: [kt_menu] (filters + every dish) and [kt_menu featured="1"]
 * ---------------------------------------------------------------------- */

function kt_card( array $d ) {
	$slides = '';
	foreach ( $d['imgs'] ?: [ '' ] as $i => $src ) {
		$slides .= '<img src="' . esc_url( $src ) . '" alt="' . ( $i ? '' : esc_attr( $d['name'] ) ) . '" loading="lazy" width="720" height="720">';
	}
	$dots = count( $d['imgs'] ) > 1 ? '<span class="kt-card__dots">' . str_repeat( '<i></i>', count( $d['imgs'] ) ) . '</span>' : '';
	$heat = in_array( 'spice', $d['opts'], true ) ? '<span class="kt-meta kt-meta--heat">' . kt_chillies( max( 1, $d['heat'] ), 5 ) . 'Set 1–5</span>' : ( $d['heat'] ? '<span class="kt-meta kt-meta--heat">' . kt_chillies( $d['heat'] ) . '</span>' : '' );
	$diet = '';
	foreach ( [ 'vegan' => 'VG', 'vegetarian' => 'V', 'gluten-free' => 'GF' ] as $t => $abbr ) {
		if ( in_array( $t, $d['tags'], true ) ) {
			$diet .= '<abbr class="kt-diet" title="' . esc_attr( KT_DIETS[ $t ] . ( $d['choices'] ? ' option' : '' ) ) . '">' . $abbr . '</abbr>';
		}
	}
	if ( in_array( 'peanuts', $d['tags'], true ) ) {
		$diet .= '<abbr class="kt-diet kt-diet--alert" title="Contains peanuts">P</abbr>';
	}
	$simple = ! $d['choices'] && ! $d['opts'];
	$wa     = 'Hi Khrung Thep, I\'d like to order: ' . $d['name'] . ' (' . kt_money( $d['price'] ) . ').';
	return sprintf(
		'<article class="kt-card" data-kt-card data-id="%1$d" data-cat="%2$s" data-tags="%3$s" data-heat="%4$d" data-spice="%5$s" data-price="%6$d" data-order="%7$d" data-name="%8$s">
			<div class="kt-card__media"><a class="kt-card__slides" href="%9$s" data-kt-dish="%1$d" aria-label="%10$s">%11$s</a>%12$s%13$s</div>
			<div class="kt-card__body">
				<p class="kt-card__thai"><span lang="th">%14$s</span>%15$s</p>
				<h3 class="kt-card__title"><a href="%9$s" data-kt-dish="%1$d">%10$s</a></h3>
				<p class="kt-card__short">%16$s</p>
				<div class="kt-card__metas">%17$s%18$s%19$s</div>
				<div class="kt-card__foot">
					<p class="kt-card__price">%20$s</p>
					<div class="kt-card__actions">
						<a class="kt-icon-btn kt-icon-btn--wa" href="%21$s" target="_blank" rel="noopener" aria-label="Order %10$s on WhatsApp" data-kt-wa-item="%1$d">%22$s</a>
						<button type="button" class="kt-btn-line" data-kt-dish="%1$d">Customise</button>
						<button type="button" class="kt-btn-add" data-kt-quick="%1$d"%23$s aria-label="Add %10$s to your order">Add</button>
					</div>
				</div>
			</div>
		</article>',
		$d['id'],
		esc_attr( $d['cat'] ),
		esc_attr( implode( ' ', $d['tags'] ) ),
		$d['heat'],
		in_array( 'spice', $d['opts'], true ) ? '1' : '0',
		(int) $d['price'],
		$d['order'],
		esc_attr( strtolower( $d['name'] . ' ' . $d['roman'] . ' ' . implode( ' ', $d['ingr'] ) . ' ' . implode( ' ', array_column( $d['choices'], 'label' ) ) . ' ' . $d['catName'] ) ),
		esc_url( $d['url'] ),
		esc_attr( $d['name'] ),
		$slides,
		$dots,
		$d['badge'] ? '<span class="kt-card__badge">' . esc_html( $d['badge'] ) . '</span>' : '',
		esc_html( $d['thai'] ),
		$d['roman'] && $d['roman'] !== $d['name'] ? ' · ' . esc_html( $d['roman'] ) : '',
		esc_html( $d['short'] ),
		$heat,
		$d['portion'] ? '<span class="kt-meta">' . esc_html( $d['portion'] ) . '</span>' : '',
		$diet ? '<span class="kt-diets">' . $diet . '</span>' : '',
		( $d['choices'] ? '<small>from</small> ' : '' ) . esc_html( kt_money( $d['price'] ) ),
		esc_url( kt_wa_link( $wa ) ),
		KT_WA_ICON,
		$simple ? '' : ' data-kt-has-opts'
	);
}

add_shortcode( 'kt_menu', function ( $atts ) {
	$atts = shortcode_atts( [ 'featured' => '', 'cat' => '' ], $atts );
	$menu = kt_menu_data();
	if ( $atts['featured'] ) {
		$h = '<div class="kt-grid kt-grid--featured">';
		foreach ( $menu as $d ) {
			if ( $d['featured'] ) $h .= kt_card( $d );
		}
		return $h . '</div>';
	}
	$current = $atts['cat'];
	$q       = get_queried_object();
	if ( ! $current && $q instanceof WP_Term && $q->taxonomy === 'product_cat' ) {
		$current = $q->slug;
	}
	$cats  = kt_categories();
	$chips = '<button type="button" class="kt-chip' . ( $current ? '' : ' is-on' ) . '" data-kt-cat="">All</button>';
	foreach ( $cats as $t ) {
		$chips .= '<button type="button" class="kt-chip' . ( $current === $t->slug ? ' is-on' : '' ) . '" data-kt-cat="' . esc_attr( $t->slug ) . '">' . esc_html( $t->name ) . '</button>';
	}
	$diets = '';
	foreach ( KT_DIETS as $slug => $label ) {
		$diets .= '<button type="button" class="kt-chip kt-chip--sm" data-kt-diet="' . esc_attr( $slug ) . '" aria-pressed="false">' . esc_html( $label ) . '</button>';
	}
	$diets .= '<button type="button" class="kt-chip kt-chip--sm" data-kt-diet="no-peanuts" aria-pressed="false">No peanuts</button>';

	ob_start();
	?>
	<div class="kt-menu" data-kt-menu<?php echo $current ? ' data-start-cat="' . esc_attr( $current ) . '"' : ''; ?>>
		<div class="kt-hub" data-kt-hub>
			<div class="kt-hub__row kt-hub__row--top">
				<label class="kt-search"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="m21 21-4.3-4.3M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Z"/></svg><span class="screen-reader-text">Search the menu</span><input type="search" placeholder="Search Pad Thai, matcha, prawns…" data-kt-q autocomplete="off"></label>
				<div class="kt-seg" role="group" aria-label="How you want it" data-kt-mode-group>
					<button type="button" data-kt-mode="delivery" aria-pressed="true">🛵 Delivery</button>
					<button type="button" data-kt-mode="pickup" aria-pressed="false">🚗 Kerbside pickup</button>
					<button type="button" data-kt-mode="dinein" aria-pressed="false">🍽 Dine-in</button>
				</div>
			</div>
			<div class="kt-hub__row kt-chips" role="group" aria-label="Menu section"><?php echo $chips; // phpcs:ignore ?></div>
			<details class="kt-hub__more" data-kt-more>
				<summary><span>Spice, diet &amp; budget</span><em data-kt-active></em></summary>
				<div class="kt-hub__filters">
					<div class="kt-filter"><p>Spice level</p>
						<div class="kt-seg kt-seg--spice" role="group" aria-label="Spice level">
							<button type="button" data-kt-spice="" aria-pressed="true">Any</button>
							<button type="button" data-kt-spice="1" aria-pressed="false"><?php echo kt_chillies( 1 ); // phpcs:ignore ?> Mild</button>
							<button type="button" data-kt-spice="2" aria-pressed="false"><?php echo kt_chillies( 2 ); // phpcs:ignore ?> Medium</button>
							<button type="button" data-kt-spice="3" aria-pressed="false"><?php echo kt_chillies( 3 ); // phpcs:ignore ?> Authentic Thai hot</button>
						</div>
					</div>
					<div class="kt-filter"><p>Diet &amp; protein</p><div class="kt-chips"><?php echo $diets; // phpcs:ignore ?></div></div>
					<div class="kt-filter kt-filter--price"><p>Budget <strong data-kt-price-label>Any price</strong></p>
						<input type="range" min="500" max="2500" step="100" value="2500" data-kt-price aria-label="Highest price">
						<div class="kt-range-ends"><span>KSh 500</span><span>KSh 2,000+</span></div>
					</div>
				</div>
			</details>
			<div class="kt-hub__status"><p data-kt-count aria-live="polite"></p><div><select data-kt-sort aria-label="Sort the menu"><option value="">Menu order</option><option value="popular">Most loved first</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select><button type="button" class="kt-link-btn" data-kt-clear hidden>Clear filters</button></div></div>
			<p class="kt-mode-note" data-kt-mode-note></p>
		</div>
		<?php foreach ( $cats as $t ) : ?>
			<section class="kt-menu__sec" id="<?php echo esc_attr( $t->slug ); ?>" data-kt-sec="<?php echo esc_attr( $t->slug ); ?>">
				<div class="kt-menu__head"><h2><?php echo esc_html( $t->name ); ?></h2><p><?php echo esc_html( $t->description ); ?></p></div>
				<div class="kt-grid">
					<?php
					foreach ( $menu as $d ) {
						if ( $d['cat'] === $t->slug ) echo kt_card( $d ); // phpcs:ignore
					}
					?>
				</div>
			</section>
		<?php endforeach; ?>
		<div class="kt-empty" data-kt-empty hidden><p>Nothing matches all of that. <button type="button" class="kt-link-btn" data-kt-clear>Clear the filters</button> or <a href="<?php echo esc_url( kt_wa_link( 'Hi Khrung Thep, can you make me something special?' ) ); ?>" target="_blank" rel="noopener">ask the kitchen on WhatsApp</a>.</p></div>
	</div>
	<?php
	return ob_get_clean();
} );

// Hero craving finder: a few taps, then the menu opens filtered.
add_shortcode( 'kt_finder', function () {
	$cats = '';
	foreach ( kt_categories() as $t ) {
		$cats .= '<option value="' . esc_attr( $t->slug ) . '">' . esc_html( $t->name ) . '</option>';
	}
	$diets = '';
	foreach ( KT_DIETS as $slug => $label ) {
		$diets .= '<option value="' . esc_attr( $slug ) . '">' . esc_html( $label ) . '</option>';
	}
	return '<form class="kt-finder" action="' . esc_url( home_url( '/menu/' ) ) . '" method="get" data-kt-finder>
		<p class="kt-finder__title">What are you craving?</p>
		<div class="kt-finder__grid">
			<label>Craving<select name="cat"><option value="">Everything</option>' . $cats . '</select></label>
			<label>Spice<select name="spice"><option value="">Any heat</option><option value="1">Mild</option><option value="2">Medium</option><option value="3">Authentic Thai hot</option></select></label>
			<label>Diet<select name="diet"><option value="">No preference</option>' . $diets . '</select></label>
			<label>Budget<select name="max"><option value="">Any</option><option value="700">Up to KSh 700</option><option value="1000">Up to KSh 1,000</option><option value="1500">Up to KSh 1,500</option><option value="2000">Up to KSh 2,000</option></select></label>
		</div>
		<div class="kt-seg kt-seg--light" role="group" aria-label="How you want it" data-kt-mode-group>
			<button type="button" data-kt-mode="delivery" aria-pressed="true">Delivery</button><button type="button" data-kt-mode="pickup" aria-pressed="false">Pickup</button><button type="button" data-kt-mode="dinein" aria-pressed="false">Dine-in</button>
		</div>
		<button type="submit" class="wp-element-button kt-finder__go">Show me the dishes</button>
	</form>';
} );

/* -------------------------------------------------------------------------
 * Dish options on the cart line: spice, extras, sweetness, milk, note
 * ---------------------------------------------------------------------- */

/** Cleans submitted options against what the dish offers. */
function kt_clean_options( $raw, $product_id ) {
	$raw  = is_array( $raw ) ? $raw : [];
	$opts = kt_opts( $product_id );
	$out  = [];
	if ( in_array( 'spice', $opts, true ) ) {
		$s            = (int) ( $raw['spice'] ?? 0 );
		$out['spice'] = $s >= 1 && $s <= 5 ? $s : max( 1, min( 5, (int) get_post_meta( $product_id, '_kt_heat', true ) + 1 ) );
	}
	if ( in_array( 'extras', $opts, true ) ) {
		$ex = array_values( array_intersect( (array) ( $raw['extras'] ?? [] ), array_keys( KT_EXTRAS ) ) );
		if ( $ex ) $out['extras'] = $ex;
	}
	if ( in_array( 'sweet', $opts, true ) ) {
		$sw = (string) ( $raw['sweet'] ?? 'regular' );
		if ( isset( KT_SWEET[ $sw ] ) && $sw !== 'regular' ) $out['sweet'] = $sw;
	}
	if ( in_array( 'milk', $opts, true ) ) {
		$m = (string) ( $raw['milk'] ?? 'regular' );
		if ( isset( KT_MILK[ $m ] ) && $m !== 'regular' ) $out['milk'] = $m;
	}
	$note = trim( sanitize_text_field( (string) ( $raw['note'] ?? '' ) ) );
	if ( $note !== '' ) $out['note'] = mb_substr( $note, 0, 160 );
	return $out;
}

/** What the options add to one item's price. */
function kt_options_cost( array $o ) {
	$add = 0;
	foreach ( $o['extras'] ?? [] as $e ) {
		$add += KT_EXTRAS[ $e ][1] ?? 0;
	}
	return $add + ( KT_MILK[ $o['milk'] ?? 'regular' ][1] ?? 0 );
}

/** The options as label => value lines, for the cart, the order and WhatsApp. */
function kt_options_lines( array $o ) {
	$out = [];
	if ( ! empty( $o['spice'] ) ) $out['Spice'] = str_repeat( '🌶', $o['spice'] ) . ' ' . $o['spice'] . '/5 (' . KT_SPICE[ $o['spice'] ] . ')';
	if ( ! empty( $o['extras'] ) ) $out['Extras'] = implode( ', ', array_map( fn( $e ) => KT_EXTRAS[ $e ][0] . ' +' . kt_money( KT_EXTRAS[ $e ][1] ), $o['extras'] ) );
	if ( ! empty( $o['sweet'] ) ) $out['Sweetness'] = KT_SWEET[ $o['sweet'] ];
	if ( ! empty( $o['milk'] ) ) $out['Milk'] = KT_MILK[ $o['milk'] ][0] . ' +' . kt_money( KT_MILK[ $o['milk'] ][1] );
	if ( ! empty( $o['note'] ) ) $out['Note'] = $o['note'];
	return $out;
}

// Product page form (classic POST) and the Store API (our dish pop-up sends "kt": {...}).
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	if ( isset( $data['kt'] ) ) {
		return $data;
	}
	if ( isset( $_POST['kt'] ) ) { // phpcs:ignore
		$data['kt'] = kt_clean_options( wp_unslash( $_POST['kt'] ), $product_id ); // phpcs:ignore
	} elseif ( kt_opts( $product_id ) ) {
		$data['kt'] = kt_clean_options( [], $product_id );
	}
	return $data;
}, 10, 2 );
add_filter( 'woocommerce_store_api_add_to_cart_data', function ( $data, $request ) {
	$product   = wc_get_product( $data['id'] );
	$parent_id = $product && $product->get_parent_id() ? $product->get_parent_id() : (int) $data['id'];
	$data['cart_item_data']       = $data['cart_item_data'] ?? [];
	$data['cart_item_data']['kt'] = kt_clean_options( $request['kt'] ?? [], $parent_id );
	return $data;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['kt'] ) ) continue;
		$base = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $base ) $item['data']->set_price( (float) $base->get_price() + kt_options_cost( $item['kt'] ) );
	}
}, 20 );

add_filter( 'woocommerce_get_item_data', function ( $rows, $item ) {
	foreach ( kt_options_lines( $item['kt'] ?? [] ) as $k => $v ) {
		$rows[] = [ 'key' => $k, 'value' => $v ];
	}
	return $rows;
}, 10, 2 );
add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $values ) {
	foreach ( kt_options_lines( $values['kt'] ?? [] ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Dish page
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to my order' );
add_filter( 'woocommerce_product_add_to_cart_text', fn( $t, $p ) => $p && $p->is_in_stock() ? 'Add to order' : $t, 10, 2 );
add_filter( 'woocommerce_get_availability_text', fn( $text, $product ) => $product->is_in_stock() ? 'Made to order today · delivery or kerbside pickup' : 'Sold out today', 10, 2 );
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? $html : '<span class="kt-from">from</span> ' . wc_price( $min );
}, 10, 2 );

add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id    = $product->get_id();
	$thai  = get_post_meta( $id, '_kt_thai', true );
	$likes = get_post_meta( $id, '_kt_likes', true );
	echo '<p class="kt-pdp-thai"><span lang="th">' . esc_html( $thai ) . '</span> · ' . esc_html( get_post_meta( $id, '_kt_roman', true ) ) . '</p>';
	echo '<div class="kt-tags">' . ( get_post_meta( $id, '_kt_badge', true ) ? '<span class="kt-tag">' . esc_html( get_post_meta( $id, '_kt_badge', true ) ) . '</span>' : '' ) . ( $likes && ! str_contains( (string) get_post_meta( $id, '_kt_badge', true ), 'Uber' ) ? '<span class="kt-tag kt-tag--line">Uber Eats: ' . esc_html( $likes ) . '</span>' : '' ) . ( get_post_meta( $id, '_kt_portion', true ) ? '<span class="kt-tag kt-tag--line">' . esc_html( get_post_meta( $id, '_kt_portion', true ) ) . '</span>' : '' ) . '</div>';
	if ( has_term( 'peanuts', 'product_tag', $id ) ) {
		echo '<p class="kt-alert">⚠ Contains peanuts. Allergic? Say so in the note and we\'ll tell you what\'s safe.</p>';
	}
	if ( get_post_meta( $id, '_kt_drawn', true ) === 'yes' ) {
		echo '<p class="kt-note">The picture is a drawing, not a photo of this item.</p>';
	}
} );

// Spice, extras, sweetness and milk fields inside the add-to-cart form (posted as kt[...]).
add_action( 'woocommerce_before_add_to_cart_button', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id   = $product->get_id();
	$opts = kt_opts( $id );
	if ( ! $opts ) return;
	$heat = max( 1, min( 5, (int) get_post_meta( $id, '_kt_heat', true ) + 1 ) );
	echo '<div class="kt-pdp-opts" data-kt-pdp-opts>';
	if ( in_array( 'spice', $opts, true ) ) {
		echo '<fieldset class="kt-opt"><legend>Spice level <em>1 = gentle, 5 = authentic Thai hot</em></legend><div class="kt-spice">';
		foreach ( KT_SPICE as $n => $label ) {
			echo '<label><input type="radio" name="kt[spice]" value="' . $n . '"' . checked( $n, $heat, false ) . '><span>' . kt_chillies( $n ) . '<b>' . $n . '</b><small>' . esc_html( $label ) . '</small></span></label>'; // phpcs:ignore
		}
		echo '</div></fieldset>';
	}
	if ( in_array( 'extras', $opts, true ) ) {
		echo '<fieldset class="kt-opt"><legend>Extras</legend><div class="kt-checks">';
		foreach ( KT_EXTRAS as $k => [ $label, $price ] ) {
			echo '<label><input type="checkbox" name="kt[extras][]" value="' . esc_attr( $k ) . '" data-kt-cost="' . (int) $price . '"><span>' . esc_html( $label ) . '</span><b>+' . esc_html( kt_money( $price ) ) . '</b></label>';
		}
		echo '</div></fieldset>';
	}
	if ( in_array( 'sweet', $opts, true ) ) {
		echo '<fieldset class="kt-opt"><legend>Sweetness</legend><div class="kt-pills">';
		foreach ( KT_SWEET as $k => $label ) {
			echo '<label><input type="radio" name="kt[sweet]" value="' . esc_attr( $k ) . '"' . checked( $k, 'regular', false ) . '><span>' . esc_html( $label ) . '</span></label>';
		}
		echo '</div></fieldset>';
	}
	if ( in_array( 'milk', $opts, true ) ) {
		echo '<fieldset class="kt-opt"><legend>Milk</legend><div class="kt-pills">';
		foreach ( KT_MILK as $k => [ $label, $price ] ) {
			echo '<label><input type="radio" name="kt[milk]" value="' . esc_attr( $k ) . '" data-kt-cost="' . (int) $price . '"' . checked( $k, 'regular', false ) . '><span>' . esc_html( $label ) . ( $price ? ' +' . esc_html( kt_money( $price ) ) : '' ) . '</span></label>';
		}
		echo '</div></fieldset>';
	}
	echo '<label class="kt-opt kt-opt--note">Allergies or requests<input type="text" name="kt[note]" maxlength="160" placeholder="e.g. no peanuts, sauce on the side"></label>';
	echo '</div>';
} );

add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id  = $product->get_id();
	$msg = 'Hi Khrung Thep, I\'d like to order: ' . $product->get_name() . '. ' . $product->get_permalink();
	echo '<a class="kt-wa-order" data-kt-wa-pdp="' . esc_attr( $product->get_name() ) . '" href="' . esc_url( kt_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . KT_WA_ICON . 'Instant WhatsApp order · ' . esc_html( KT_PHONE ) . '</a>';
	$clip = get_post_meta( $id, '_kt_clip', true );
	if ( $clip ) {
		echo '<figure class="kt-pdp-clip"><video src="' . esc_url( get_stylesheet_directory_uri() . '/assets/clips/' . $clip . '.mp4' ) . '" muted loop playsinline autoplay preload="metadata"></video><figcaption>' . esc_html( [ 'matcha' => 'Every cup is whisked by hand, to order.', 'wok' => 'Wok-fired to order in our kitchen.', 'noodles' => 'Our rice noodles, made fresh every morning.' ][ $clip ] ?? '' ) . '</figcaption></figure>';
	}
	$reel = get_post_meta( $id, '_kt_reel', true );
	if ( $reel ) {
		echo '<a class="kt-reel" href="' . esc_url( $reel ) . '" target="_blank" rel="noopener"><span aria-hidden="true">▶</span>Watch it on our Instagram</a>';
	}
	echo '<div class="kt-promise"><div><span aria-hidden="true">🔥</span><p><strong>Cooked when you order</strong>Nothing sits under a lamp: wok-fired, pounded or whisked for you.</p></div><div><span aria-hidden="true">🛵</span><p><strong>Delivery or kerbside pickup</strong>Our riders across Westlands &amp; nearby, or we bring it to your car at the gate.</p></div><div><span aria-hidden="true">✓</span><p><strong>Pay on delivery</strong>M-Pesa or cash when it reaches you.</p></div></div>';
} );

add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) return $tabs;
	$id = $product->get_id();
	if ( isset( $tabs['description'] ) ) $tabs['description']['title'] = 'About this dish';
	$ingr = kt_lines( $id, 'ingredients' );
	$alg  = kt_lines( $id, 'allergens' );
	$tabs['kt_sheet'] = [
		'title'    => 'Ingredients & allergens',
		'priority' => 5,
		'callback' => function () use ( $id, $ingr, $alg ) {
			echo '<div class="kt-sheet"><div><h3>Key ingredients</h3><ul class="kt-checks-list">';
			foreach ( $ingr as $s ) echo '<li>' . esc_html( $s ) . '</li>';
			echo '</ul></div><div><h3>Allergens</h3>' . ( $alg ? '<ul class="kt-alg">' . implode( '', array_map( fn( $a ) => '<li>' . esc_html( $a ) . '</li>', $alg ) ) . '</ul>' : '<p>None of the common allergens.</p>' );
			$vn = get_post_meta( $id, '_kt_vegan_note', true );
			if ( $vn ) echo '<p class="kt-note">' . esc_html( $vn ) . '</p>';
			echo '<p class="kt-small">Our kitchen also handles peanuts, shellfish, egg, soy, sesame and fish sauce. Tell us about any allergy before you order.</p></div></div>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

/* -------------------------------------------------------------------------
 * Requests: table reservations, events & private dining, Tasting Club
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	register_post_type( 'kt_request', [
		'label'           => 'Bookings & requests',
		'labels'          => [ 'name' => 'Bookings & requests', 'singular_name' => 'Request', 'edit_item' => 'Request', 'all_items' => 'Bookings & requests' ],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'woocommerce',
		'supports'        => [ 'title', 'editor' ],
		'capability_type' => 'post',
		'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap'    => true,
	] );
} );

// type => [ title, reference letter, WhatsApp opening line ].
const KT_REQUEST_TYPES = [
	'table' => [ 'Table reservation', 'T', 'Hi Khrung Thep, I\'d like to reserve a table' ],
	'event' => [ 'Event / private dining', 'E', 'Hi Khrung Thep, I\'d like a quote for an event' ],
	'club'  => [ 'Tasting Club sign-up', 'C', 'Hi Khrung Thep, please add me to the Tasting Club' ],
];
// What each form sends: field => label. Required fields end in "*".
const KT_REQUEST_FIELDS = [
	'table' => [ 'date*' => 'Date', 'time*' => 'Time', 'guests*' => 'Guests', 'seating' => 'Seating', 'occasion' => 'Occasion', 'name*' => 'Name', 'phone*' => 'Phone', 'notes' => 'Notes' ],
	'event' => [ 'kind*' => 'Event', 'date*' => 'Date', 'guests*' => 'Guests', 'where' => 'Where', 'budget' => 'Budget per head', 'name*' => 'Name', 'phone*' => 'Phone', 'notes' => 'Notes' ],
	'club'  => [ 'name*' => 'Name', 'contact*' => 'WhatsApp or email' ],
];

add_filter( 'manage_kt_request_posts_columns', fn( $c ) => [ 'cb' => $c['cb'], 'title' => 'Request', 'kt_type' => 'Type', 'kt_phone' => 'Contact', 'date' => 'Received' ] );
add_action( 'manage_kt_request_posts_custom_column', function ( $col, $id ) {
	if ( $col === 'kt_type' ) echo esc_html( KT_REQUEST_TYPES[ get_post_meta( $id, '_kt_type', true ) ][0] ?? '' );
	if ( $col === 'kt_phone' ) {
		$c      = get_post_meta( $id, '_kt_contact', true );
		$digits = preg_replace( '/\D/', '', (string) $c );
		echo strlen( $digits ) >= 9 && ! str_contains( $c, '@' ) ? '<a href="https://wa.me/' . esc_attr( str_starts_with( $digits, '0' ) ? '254' . substr( $digits, 1 ) : $digits ) . '" target="_blank" rel="noopener">' . esc_html( $c ) . '</a>' : esc_html( $c );
	}
}, 10, 2 );

add_action( 'rest_api_init', function () {
	register_rest_route( 'kt/v1', '/request', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$type = sanitize_key( $req['type'] );
			if ( ! isset( KT_REQUEST_FIELDS[ $type ] ) ) {
				return new WP_Error( 'kt_type', 'Unknown request.', [ 'status' => 400 ] );
			}
			if ( ! empty( $req['website'] ) ) { // a field people can't see: only bots fill it in
				return new WP_Error( 'kt_spam', 'Request not sent.', [ 'status' => 400 ] );
			}
			$ip   = 'kt_rl_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' );
			$hits = (int) get_transient( $ip );
			if ( $hits >= 8 ) {
				return new WP_Error( 'kt_slow', 'Too many requests. Please call or WhatsApp us on ' . KT_PHONE . '.', [ 'status' => 429 ] );
			}
			set_transient( $ip, $hits + 1, 10 * MINUTE_IN_SECONDS );

			$data = [];
			$rows = [];
			foreach ( KT_REQUEST_FIELDS[ $type ] as $key => $label ) {
				$field = rtrim( $key, '*' );
				$value = trim( sanitize_text_field( (string) $req[ $field ] ) );
				if ( $field === 'date' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
					$value = wp_date( 'D j M Y', strtotime( $value . ' 12:00' ) );
				}
				if ( $field === 'time' && preg_match( '/^\d{2}:\d{2}$/', $value ) ) {
					$value = gmdate( 'g:i a', strtotime( '2000-01-01 ' . $value . ' UTC' ) );
				}
				if ( $value === '' && str_ends_with( $key, '*' ) ) {
					return new WP_Error( 'kt_missing', 'Please fill in: ' . $label . '.', [ 'status' => 400 ] );
				}
				$data[ $field ] = mb_substr( $value, 0, 600 );
				if ( $data[ $field ] !== '' ) $rows[] = $label . ': ' . $data[ $field ];
			}
			[ $title, $letter, $intro ] = KT_REQUEST_TYPES[ $type ];
			$id = wp_insert_post( [ 'post_type' => 'kt_request', 'post_status' => 'publish', 'post_title' => $title . ' – ' . $data['name'], 'post_content' => implode( "\n", $rows ) ] );
			if ( ! $id || is_wp_error( $id ) ) {
				return new WP_Error( 'kt_save', 'Could not save your request. Please WhatsApp us on ' . KT_PHONE . '.', [ 'status' => 500 ] );
			}
			$ref = 'KT-' . $letter . $id;
			update_post_meta( $id, '_kt_type', $type );
			update_post_meta( $id, '_kt_contact', $data['phone'] ?? $data['contact'] ?? '' );
			update_post_meta( $id, '_kt_ref', $ref );
			wp_update_post( [ 'ID' => $id, 'post_title' => $title . ' – ' . $data['name'] . ' (' . $ref . ')' ] );
			wp_mail( get_option( 'admin_email' ), 'New ' . strtolower( $title ) . ' ' . $ref, implode( "\n", $rows ) );
			$text = $intro . " (ref $ref):\n" . implode( "\n", $rows );
			return [ 'ref' => $ref, 'wa' => kt_wa_link( $text ) ];
		},
	] );
} );

/** Dates for the next N days: Y-m-d => "Fri 9 Oct". */
function kt_dates( $days = 30 ) {
	$out = [];
	$day = new DateTime( 'today', wp_timezone() );
	for ( $i = 0; $i < $days; $i++ ) {
		$out[ $day->format( 'Y-m-d' ) ] = ( $i === 0 ? 'Today, ' : ( $i === 1 ? 'Tomorrow, ' : '' ) ) . $day->format( 'D j M' );
		$day->modify( '+1 day' );
	}
	return $out;
}
/** Table times, every 30 minutes, from noon until an hour before closing. */
function kt_times() {
	$out = [];
	for ( $t = strtotime( '12:00' ); $t <= strtotime( KT_CLOSE ) - HOUR_IN_SECONDS; $t += 30 * MINUTE_IN_SECONDS ) {
		$out[ gmdate( 'H:i', $t ) ] = gmdate( 'g:i a', $t );
	}
	return $out;
}

function kt_reserve_form( $in_dialog = false ) {
	$opt = fn( array $o ) => implode( '', array_map( fn( $k, $v ) => '<option value="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</option>', array_keys( $o ), $o ) );
	$guests = '';
	foreach ( range( 1, 10 ) as $n ) {
		$guests .= '<label><input type="radio" name="guests" value="' . $n . '"' . ( $n === 2 ? ' checked' : '' ) . '><span>' . $n . '</span></label>';
	}
	$guests .= '<label><input type="radio" name="guests" value="11+ (group)"><span>11+</span></label>';
	return '<form class="kt-form kt-reserve" data-kt-request="table" novalidate>
		<div class="kt-form__grid">
			<label>Date<select name="date" required>' . $opt( kt_dates() ) . '</select></label>
			<label>Time<select name="time" required>' . $opt( kt_times() ) . '</select></label>
		</div>
		<fieldset class="kt-opt"><legend>Guests</legend><div class="kt-pills kt-pills--num">' . $guests . '</div></fieldset>
		<div class="kt-form__grid">
			<label>Seating<select name="seating"><option>Garden, under the lights</option><option>Covered terrace</option><option>No preference</option></select></label>
			<label>Occasion<select name="occasion"><option value="">Just dinner</option><option>Date night</option><option>Birthday</option><option>Business lunch</option><option>Celebration</option></select></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone / WhatsApp<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required placeholder="07…"></label>
		</div>
		<label class="kt-form__full">Anything we should know?<input type="text" name="notes" maxlength="300" placeholder="High chair, allergies, a surprise cake…"></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="kt-hp" aria-hidden="true">
		<p class="kt-peak" data-kt-peak hidden>🔥 Peak hour in the garden: Friday &amp; Saturday evenings fill first. Send your request now and we hold your table.</p>
		<button type="submit" class="wp-element-button kt-form__go">Request this table</button>
		<p class="kt-small">We confirm on WhatsApp within minutes during opening hours. For 11 or more, see <a href="/events/">events &amp; private dining</a>.</p>
	</form>';
}
add_shortcode( 'kt_reserve_form', fn() => kt_reserve_form() );

add_shortcode( 'kt_event_form', function () {
	return '<form class="kt-form" data-kt-request="event" novalidate>
		<div class="kt-form__grid">
			<label>Event<select name="kind" required><option>Birthday or celebration</option><option>Team lunch / corporate</option><option>Office lunch delivery (Corporate Lunch)</option><option>Private garden dinner</option><option>Date night for two</option><option>Something else</option></select></label>
			<label>Date<input type="date" name="date" required min="' . esc_attr( wp_date( 'Y-m-d' ) ) . '"></label>
			<label>Guests<input type="number" name="guests" min="2" max="300" value="12" inputmode="numeric" required></label>
			<label>Where<select name="where"><option>At Khrung Thep, Westlands</option><option>Delivered to our office or home</option></select></label>
			<label>Budget per head<select name="budget"><option>KSh 1,000 – 1,500</option><option selected>KSh 1,500 – 2,000</option><option>KSh 2,000 – 3,000</option><option>KSh 3,000+</option></select></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone / WhatsApp<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required></label>
		</div>
		<label class="kt-form__full">Tell us more<input type="text" name="notes" maxlength="400" placeholder="Dietary needs, time, cake, décor…"></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="kt-hp" aria-hidden="true">
		<button type="submit" class="wp-element-button kt-form__go">Get my menu &amp; quote</button>
		<p class="kt-small">We reply on WhatsApp with a set menu and a price per head.</p>
	</form>';
} );

add_shortcode( 'kt_club_form', function () {
	return '<form class="kt-club" data-kt-request="club" novalidate>
		<label><span class="screen-reader-text">Your name</span><input type="text" name="name" placeholder="Your name" autocomplete="name" required></label>
		<label><span class="screen-reader-text">WhatsApp number or email</span><input type="text" name="contact" placeholder="WhatsApp number or email" required></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="kt-hp" aria-hidden="true">
		<button type="submit" class="wp-element-button">Join the club</button>
	</form>';
} );

// Reviews: Google (4.3 from 159) and Uber Eats (4.3 from 430+), and real Google reviews.
add_shortcode( 'kt_reviews', function () {
	$reviews = [
		[ 'Probably some of the most authentic Thai food we have seen. The service, the food, the drinks: A1 tier through and through.', 'Chido M', 'Local Guide · Google review' ],
		[ 'Tucked in a private, quiet, and leafy corner within a very safe and secure compound, Krung Thep Thai brings back instant memories of the night market stalls of Chiang Mai and Pattaya.', 'Naman Anand', 'Local Guide · Google review' ],
		[ 'The service here was excellent. They also have a very attentive manager. The food was great too. I especially loved the prawn starter. Delicious!', 'Laura Althea', 'Local Guide · Google review' ],
	];
	$h  = '<div class="kt-reviews"><div class="kt-scores">';
	$h .= '<a class="kt-score" href="' . esc_url( KT_MAPS ) . '" target="_blank" rel="noopener"><strong>4.3<span>★</span></strong><span>Google · 159 reviews</span></a>';
	$h .= '<a class="kt-score" href="' . esc_url( KT_UBER ) . '" target="_blank" rel="noopener"><strong>4.3<span>★</span></strong><span>Uber Eats · 430+ ratings</span></a>';
	$h .= '<a class="kt-score" href="' . esc_url( KT_IG ) . '" target="_blank" rel="noopener"><strong>17.1K</strong><span>foodies on Instagram</span></a>';
	$h .= '<div class="kt-score kt-score--dish"><p>Uber Eats thumbs-up</p><ul><li><span>Papaya Salad</span><b>95%</b></li><li><span>Pad Kra Pao Gai</span><b>86%</b></li><li><span>Thai Iced Tea</span><b>83%</b></li><li><span>Thai BBQ Wings</span><b>83%</b></li></ul></div>';
	$h .= '</div><div class="kt-reviews__list">';
	foreach ( $reviews as [ $text, $who, $where ] ) {
		$h .= '<figure class="kt-review"><div class="kt-stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote>' . esc_html( $text ) . '</blockquote><figcaption><strong>' . esc_html( $who ) . '</strong><span>' . esc_html( $where ) . '</span></figcaption></figure>';
	}
	return $h . '</div></div>';
} );

/* -------------------------------------------------------------------------
 * Dialogs, floating WhatsApp
 * ---------------------------------------------------------------------- */

add_action( 'wp_footer', function () {
	echo '<dialog id="kt-dish" class="kt-dialog kt-dish" aria-label="Dish details"><form method="dialog"><button class="kt-dialog__close" aria-label="Close">×</button></form><div data-kt-dish-body></div></dialog>';
	echo '<dialog id="kt-reserve" class="kt-dialog kt-dialog--form" aria-labelledby="kt-reserve-title"><form method="dialog"><button class="kt-dialog__close" aria-label="Close">×</button></form><p class="kt-eyebrow">Reserve a table</p><h2 id="kt-reserve-title">Your table in the garden</h2>' . kt_reserve_form( true ) . '</dialog>'; // phpcs:ignore
	echo '<a class="kt-wa-float" href="' . esc_url( kt_wa_link( 'Hi Khrung Thep, I\'d like to order:' ) ) . '" target="_blank" rel="noopener" aria-label="Order or reserve on WhatsApp">' . KT_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, confirmation
 * ---------------------------------------------------------------------- */

function kt_cart_note_html() {
	return '<div class="kt-cart-note"><strong>Next:</strong> delivery by our riders from KSh 200, or free kerbside pickup at 208 Sports Rd. Pay on delivery by M-Pesa or cash.</div>';
}
function kt_wa_cart_html() {
	return '<button type="button" class="kt-wa-cart" data-kt-wa-cart>' . KT_WA_ICON . 'Order this on WhatsApp instead</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => kt_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . kt_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', fn( $c ) => preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', kt_cart_note_html() . '$1', $c, 1 ) );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="kt-wa-cart-wrap">' . kt_wa_cart_html() . '</div>' );

add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Place my order' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Checkout: delivery or pickup' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your order' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Checkout' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View order' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact', 'Your order confirmation goes here.' ],
		'woocommerce/checkout-shipping-method-block'        => [ 'Delivery or kerbside pickup?', '' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Where should the rider come?', 'Building or estate, and a landmark the rider can find.' ],
		'woocommerce/checkout-shipping-address-block'       => [ 'Where should the rider come?', 'Building or estate, and a landmark the rider can find.' ],
		'woocommerce/checkout-additional-information-block' => [ 'When?', 'As soon as possible, or pick a time today.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is charged online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	if ( $block['blockName'] === 'woocommerce/checkout-shipping-method-block' ) {
		$block['attrs']['shippingText']    = 'Delivery';
		$block['attrs']['localPickupText'] = 'Kerbside pickup';
	}
	if ( $block['blockName'] === 'woocommerce/checkout-shipping-methods-block' ) {
		$block['attrs']['title']       = 'Delivery area';
		$block['attrs']['description'] = 'Fees are by distance from Sports Rd.';
	}
	// "When?" comes before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

/** Order times for today: ASAP, then every 30 minutes until closing. */
function kt_order_times() {
	$out = [ 'asap' => 'As soon as possible (about 45–60 min)' ];
	for ( $t = strtotime( '11:00' ); $t <= strtotime( KT_CLOSE ) - 30 * MINUTE_IN_SECONDS; $t += 30 * MINUTE_IN_SECONDS ) {
		$out[ gmdate( 'H:i', $t ) ] = 'Today at ' . gmdate( 'g:i a', $t );
	}
	return $out;
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) return;
	woocommerce_register_additional_checkout_field( [
		'id'       => 'kt/when',
		'label'    => 'When do you want it?',
		'location' => 'order',
		'type'     => 'select',
		'required' => true,
		'options'  => array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( kt_order_times() ), kt_order_times() ),
	] );
	woocommerce_register_additional_checkout_field( [
		'id'       => 'kt/contactless',
		'label'    => 'No-contact delivery: leave it at the door or gate and call me',
		'location' => 'order',
		'type'     => 'checkbox',
	] );
} );

// Thai Friday: the code only works on Fridays.
add_filter( 'woocommerce_coupon_is_valid', function ( $valid, $coupon ) {
	if ( strtolower( $coupon->get_code() ) === 'thaifriday' && current_time( 'N' ) !== '5' ) {
		throw new Exception( 'THAIFRIDAY works on Fridays only. See you Friday!' );
	}
	return $valid;
}, 10, 2 );

function kt_order_code( WC_Order $order ) {
	return 'KT-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function kt_order_when( WC_Order $order ) {
	$v = (string) $order->get_meta( '_wc_other/kt/when' );
	return kt_order_times()[ $v ] ?? $v;
}
function kt_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Khrung Thep, I just ordered online (' . kt_order_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$opts = [];
		foreach ( $item->get_meta_data() as $m ) {
			$d = $m->get_data();
			if ( $d['key'][0] !== '_' && ! in_array( $d['key'], [ 'protein', 'size' ], true ) ) $opts[] = $d['key'] . ': ' . wp_strip_all_tags( (string) $d['value'] );
		}
		$lines[] = '• ' . $item->get_quantity() . ' × ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ' – ' . kt_money( $item->get_total() ) . ( $opts ? "\n   " . implode( ' · ', $opts ) : '' );
	}
	$lines[] = $order->get_shipping_method() . ( (float) $order->get_shipping_total() ? ' – ' . kt_money( $order->get_shipping_total() ) : '' );
	$lines[] = 'Total: ' . kt_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	$lines[] = 'When: ' . kt_order_when( $order );
	$address = trim( implode( ', ', array_filter( [ $order->get_billing_address_1(), $order->get_billing_address_2(), $order->get_billing_city() ] ) ) );
	if ( $address && ! $order->has_shipping_method( 'pickup_location' ) ) $lines[] = 'Deliver to: ' . $address;
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return kt_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$pickup = $order->has_shipping_method( 'pickup_location' );
	return $content . '<div class="kt-thanks"><p class="kt-thanks__code">Order number <strong>' . esc_html( kt_order_code( $order ) ) . '</strong></p><p class="kt-thanks__when">' . esc_html( ( $pickup ? 'Kerbside pickup · ' : 'Delivery · ' ) . kt_order_when( $order ) ) . '</p><ol><li>We confirm on WhatsApp or by phone in a few minutes.</li><li>The kitchen fires your order: noodles, wok and matcha made fresh.</li><li>' . ( $pickup ? 'Call ' . esc_html( KT_PHONE ) . ' at the gate of 208 Sports Rd and we bring it to your car.' : 'Our rider brings it to your door. Pay by M-Pesa or cash.' ) . '</li></ol><a class="wp-element-button kt-wa-btn" href="' . esc_attr( kt_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . KT_WA_ICON . 'Send my order to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order number:</strong> ' . esc_html( kt_order_code( $order ) ) . '<br><strong>When:</strong> ' . esc_html( kt_order_when( $order ) ) . '</p>';
} );

// Staff edit the menu extras on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_kt_thai', 'label' => 'Thai name', 'description' => 'In Thai script, e.g. ผัดไทย', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_kt_roman', 'label' => 'Thai name (spelled out)', 'description' => 'e.g. Pad Kra Pao Gai', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_kt_badge', 'label' => 'Badge', 'description' => 'Short label on the photo, e.g. "Chef\'s pick".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_kt_portion', 'label' => 'Portion', 'description' => 'e.g. "One plate, with jasmine rice".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_kt_opts', 'label' => 'Options', 'description' => 'Comma-separated: spice, extras, sweet, milk.', 'desc_tip' => true ] );
	woocommerce_wp_select( [ 'id' => '_kt_heat', 'label' => 'Heat as served', 'options' => [ '0' => 'Not spicy', '1' => 'Mild', '2' => 'Medium', '3' => 'Thai hot' ] ] );
	woocommerce_wp_textarea_input( [ 'id' => '_kt_ingredients', 'label' => 'Key ingredients', 'rows' => 5, 'description' => 'One per line.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_kt_allergens', 'label' => 'Allergens', 'rows' => 4, 'description' => 'One per line.' ] );
	woocommerce_wp_text_input( [ 'id' => '_kt_reel', 'label' => 'Instagram reel link' ] );
	echo '<p class="form-field"><em>Diet filters = product tags (vegetarian, vegan, gluten-free, seafood, chicken, beef, peanuts). Protein or size prices = Variations. Mark a dish sold out with Inventory → Out of stock.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_kt_thai', '_kt_roman', '_kt_badge', '_kt_portion', '_kt_opts', '_kt_heat' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) $product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
	}
	foreach ( [ '_kt_ingredients', '_kt_allergens' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) $product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
	}
	if ( isset( $_POST['_kt_reel'] ) ) $product->update_meta_data( '_kt_reel', esc_url_raw( wp_unslash( $_POST['_kt_reel'] ) ) ); // phpcs:ignore
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['state']     = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'label' => 'Building / estate & street' ];
	$locale['KE']['address_2'] = [ 'label' => 'House or office number, gate, landmark' ];
	$locale['KE']['city']      = [ 'label' => 'Area (e.g. Westlands, Kileleshwa)' ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );

add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) return $text;
	return [
		'Related products'  => 'Goes well with',
		'Continue shopping' => 'Back to the menu',
		'Shop'              => 'Menu',
		'Shipping:'         => 'Delivery:',
		'Shipping address'  => 'Delivery address',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', fn( $text, $single, $plural, $number, $domain ) => $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your order.' : $text, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

add_action( 'wp_head', function () {
	if ( has_site_icon() ) return;
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#2E5A44\">\n";
} );

// Shortcode blocks: run the shortcode as is (the block's automatic paragraphs break the grids).
add_filter( 'pre_render_block', fn( $pre, $block ) => ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre, 10, 2 );
// Shortcodes inside custom HTML blocks on the templates.
add_filter( 'render_block_core/html', fn( $c ) => str_contains( $c, '[kt_' ) ? do_shortcode( $c ) : $c );

// Templates use root-relative links ("/menu/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) return $content;
	return preg_replace( '#\b(href|src|action|poster)="/(?!/)#', '$1="' . $home, $content );
} );
