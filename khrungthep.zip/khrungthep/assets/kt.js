( function () {
	const cfg = window.KT || {};
	const menu = cfg.menu || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s == null ? '' : s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const ls = {
		get: ( k ) => {
			try {
				return localStorage.getItem( k );
			} catch ( e ) {
				return null;
			}
		},
		set: ( k, v ) => {
			try {
				localStorage.setItem( k, v );
			} catch ( e ) {}
		},
	};
	const chillies = ( n, of ) => {
		let h = '<span class="kt-chilli" aria-hidden="true">';
		for ( let i = 1; i <= Math.max( n, of || 0 ); i++ ) h += '<i' + ( i > n ? ' class="is-off"' : '' ) + '></i>';
		return h + '</span>';
	};
	const spiceNames = ( cfg.opts && cfg.opts.spice ) || {};

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.kt-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'kt-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		// An open dialog sits in the top layer: show the toast inside it so it isn't hidden.
		const open = document.querySelector( 'dialog[open]' );
		if ( box.parentNode !== ( open || document.body ) ) ( open || document.body ).appendChild( box );
		const t = document.createElement( 'div' );
		t.className = 'kt-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3600 );
		setTimeout( () => t.remove(), 4100 );
	}
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your order · <a href="' + esc( cfg.checkout ) + '">Checkout</a>' ) );

	/* How you want it: delivery, pickup or dine-in ------------------------ */
	const MODES = { delivery: 'Delivery', pickup: 'Kerbside pickup', dinein: 'Dine-in' };
	const getMode = () => ( MODES[ ls.get( 'kt-mode' ) ] ? ls.get( 'kt-mode' ) : 'delivery' );
	function paintMode() {
		const m = getMode();
		$$( '[data-kt-mode]' ).forEach( ( b ) => b.setAttribute( 'aria-pressed', b.dataset.ktMode === m ? 'true' : 'false' ) );
		$$( '[data-kt-mode-note]' ).forEach( ( el ) => {
			el.innerHTML = {
				delivery: '🛵 <strong>Delivery</strong> by our own riders across Westlands &amp; nearby, from KSh 200. Order before the 1 pm lunch rush and it reaches you fastest.',
				pickup: '🚗 <strong>Free kerbside pickup</strong> at 208 Sports Rd. Call us at the gate and we bring it straight to your car.',
				dinein: '🍽 <strong>Eating with us?</strong> Garden tables go first on Friday &amp; Saturday evenings. <a href="/reservations/" data-kt-reserve>Reserve your table</a>, then order at the table.',
			}[ m ];
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-kt-mode]' );
		if ( ! b ) return;
		ls.set( 'kt-mode', b.dataset.ktMode );
		paintMode();
		if ( b.dataset.ktMode === 'dinein' && b.closest( '[data-kt-hub]' ) ) toast( '🍽 Dine-in: <a href="/reservations/" data-kt-reserve>reserve your garden table</a>' );
	} );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart; tell it to reload.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id, quantity, kt ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity: quantity || 1, kt: kt || {} } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		await refreshMiniCart( cart );
		document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
		setTimeout( () => refreshMiniCart(), 900 );
		return cart;
	}
	const addedMsg = ( name, qty ) => '✓ ' + ( qty > 1 ? qty + ' × ' : '' ) + esc( name ) + ' added · <a href="' + esc( cfg.checkout ) + '">Checkout</a>';

	// Quick "Add": the first choice and the dish's usual heat.
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-kt-quick]' );
		if ( ! b ) return;
		e.preventDefault();
		const d = menu[ b.dataset.ktQuick ];
		if ( ! d ) return;
		b.disabled = true;
		b.classList.add( 'is-busy' );
		try {
			const choice = d.choices && d.choices[ 0 ];
			await addItem( choice ? choice.id : d.id, 1, {} );
			b.classList.add( 'is-done' );
			b.textContent = '✓';
			setTimeout( () => {
				b.classList.remove( 'is-done' );
				b.textContent = 'Add';
			}, 1600 );
			toast( addedMsg( d.name + ( choice ? ' (' + choice.label + ')' : '' ), 1 ) + ( d.opts.length || d.choices.length ? ' · <a href="#" data-kt-dish="' + d.id + '">Customise</a>' : '' ) );
		} catch ( err ) {
			toast( esc( err.message || 'Could not add. Please try again.' ) );
		} finally {
			b.disabled = false;
			b.classList.remove( 'is-busy' );
		}
	} );

	/* WhatsApp ------------------------------------------------------------ */
	const modeLines = () => {
		const m = getMode();
		return m === 'delivery' ? [ 'Delivery to (building / estate, landmark): ' ] : m === 'pickup' ? [ 'Kerbside pickup at 208 Sports Rd, time: ' ] : [ 'Dine-in, table for: ' ];
	};
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-kt-wa-item]' );
		if ( ! a ) return;
		const d = menu[ a.dataset.ktWaItem ];
		if ( ! d ) return;
		a.href = waUrl( [ 'Hi Khrung Thep, I\'d like to order (' + MODES[ getMode() ] + '):', '• 1 × ' + d.name + ( d.choices.length ? ' (' + d.choices[ 0 ].label + ')' : '' ) + ' – ' + fmt( d.price ), ...modeLines(), 'Name: ' ].join( '\n' ) );
	} );
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		const extra = ( it.item_data || [] ).map( ( d ) => plain( d.key || d.name ) + ': ' + plain( d.value || d.display ) ).join( ' · ' );
		return '• ' + it.quantity + ' × ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) + ( extra ? '\n   ' + extra : '' );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-kt-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab inside the click so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your order is empty.' );
				return;
			}
			const lines = [ 'Hi Khrung Thep, I\'d like to order (' + MODES[ getMode() ] + '):' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Food total: ' + fmt( money( cart.totals.total_items, cart.totals ) ), ...modeLines(), 'Name: ', 'Pay by: M-Pesa / cash' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your order. Please try again.' );
		}
	} );

	/* Dish pop-up: photos, kitchen clip, options, allergens -------------- */
	const dlg = document.getElementById( 'kt-dish' );
	function dishTotal( state ) {
		const d = state.d;
		const choice = d.choices.find( ( c ) => String( c.id ) === String( state.choice ) );
		let unit = choice ? choice.price : d.price;
		( state.extras || [] ).forEach( ( k ) => ( unit += cfg.opts.extras[ k ][ 1 ] ) );
		if ( state.milk ) unit += cfg.opts.milk[ state.milk ][ 1 ];
		return { unit, total: unit * state.qty, choice };
	}
	function openDish( id ) {
		const d = menu[ id ];
		if ( ! d || ! dlg || ! dlg.showModal ) return false;
		const body = dlg.querySelector( '[data-kt-dish-body]' );
		const has = ( o ) => d.opts.indexOf( o ) > -1;
		const state = { d, qty: 1, choice: d.choices.length ? d.choices[ 0 ].id : '', spice: has( 'spice' ) ? Math.max( 1, Math.min( 5, d.heat + 1 ) ) : 0, extras: [], sweet: 'regular', milk: '', note: '' };
		const imgs = d.imgs.length ? d.imgs : [ '' ];
		const thumbs = imgs.map( ( src, i ) => '<button type="button" data-kt-dish-img="' + i + '"' + ( i ? '' : ' class="is-on"' ) + '><img src="' + esc( src ) + '" alt=""></button>' ).join( '' ) +
			( d.clip ? '<button type="button" class="kt-dish__clipbtn" data-kt-dish-clip><span>▶</span>See it made</button>' : '' );
		const base = d.choices.length ? Math.min( ...d.choices.map( ( c ) => c.price ) ) : d.price;
		const choiceHtml = d.choices.length ? '<fieldset class="kt-opt"><legend>' + esc( d.choice ) + '</legend><div class="kt-pills">' + d.choices.map( ( c, i ) => '<label><input type="radio" name="choice" value="' + c.id + '"' + ( i ? '' : ' checked' ) + '><span>' + esc( c.label ) + ( c.price > base ? ' <b>+' + fmt( c.price - base ) + '</b>' : '' ) + '</span></label>' ).join( '' ) + '</div></fieldset>' : '';
		const spiceHtml = has( 'spice' ) ? '<fieldset class="kt-opt"><legend>Spice level <em>1 gentle · 5 authentic Thai hot</em></legend><div class="kt-spice">' + [ 1, 2, 3, 4, 5 ].map( ( n ) => '<label><input type="radio" name="spice" value="' + n + '"' + ( n === state.spice ? ' checked' : '' ) + '><span>' + chillies( n ) + '<b>' + n + '</b><small>' + esc( spiceNames[ n ] ) + '</small></span></label>' ).join( '' ) + '</div></fieldset>' : '';
		const extrasHtml = has( 'extras' ) ? '<fieldset class="kt-opt"><legend>Extras</legend><div class="kt-checks">' + Object.keys( cfg.opts.extras ).map( ( k ) => '<label><input type="checkbox" name="extras" value="' + k + '"><span>' + esc( cfg.opts.extras[ k ][ 0 ] ) + '</span><b>+' + fmt( cfg.opts.extras[ k ][ 1 ] ) + '</b></label>' ).join( '' ) + '</div></fieldset>' : '';
		const sweetHtml = has( 'sweet' ) ? '<fieldset class="kt-opt"><legend>Sweetness</legend><div class="kt-pills">' + Object.keys( cfg.opts.sweet ).map( ( k ) => '<label><input type="radio" name="sweet" value="' + k + '"' + ( k === 'regular' ? ' checked' : '' ) + '><span>' + esc( cfg.opts.sweet[ k ] ) + '</span></label>' ).join( '' ) + '</div></fieldset>' : '';
		const milkHtml = has( 'milk' ) ? '<fieldset class="kt-opt"><legend>Milk</legend><div class="kt-pills">' + Object.keys( cfg.opts.milk ).map( ( k ) => '<label><input type="radio" name="milk" value="' + k + '"' + ( k === 'regular' ? ' checked' : '' ) + '><span>' + esc( cfg.opts.milk[ k ][ 0 ] ) + ( cfg.opts.milk[ k ][ 1 ] ? ' <b>+' + fmt( cfg.opts.milk[ k ][ 1 ] ) + '</b>' : '' ) + '</span></label>' ).join( '' ) + '</div></fieldset>' : '';
		const peanut = d.tags.indexOf( 'peanuts' ) > -1 ? '<p class="kt-alert">⚠ Contains peanuts. Allergic? Tell us in the note.</p>' : '';
		const diets = [ [ 'vegan', 'Vegan' ], [ 'vegetarian', 'Vegetarian' ], [ 'gluten-free', 'Gluten-free' ] ].filter( ( x ) => d.tags.indexOf( x[ 0 ] ) > -1 ).map( ( x ) => '<span class="kt-tag kt-tag--line">' + x[ 1 ] + ( d.choices.length && x[ 0 ] !== 'gluten-free' ? ' option' : '' ) + '</span>' ).join( '' );
		body.innerHTML =
			'<form class="kt-dish__grid" data-kt-dish-form>' +
			'<div class="kt-dish__media"><div class="kt-dish__main">' + imgs.map( ( src, i ) => '<img src="' + esc( src ) + '" alt="' + ( i ? '' : esc( d.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' ) +
			( d.clip ? '<video data-kt-dish-video src="' + esc( d.clip ) + '" muted loop playsinline preload="none" hidden></video>' : '' ) + ( d.badge ? '<span class="kt-card__badge">' + esc( d.badge ) + '</span>' : '' ) + '</div>' +
			'<div class="kt-dish__thumbs">' + thumbs + '</div>' + ( d.drawn ? '<p class="kt-note">The picture is a drawing, not a photo.</p>' : '' ) + '</div>' +
			'<div class="kt-dish__info">' +
			'<p class="kt-eyebrow">' + esc( d.catName ) + '</p><p class="kt-dish__thai"><span lang="th">' + esc( d.thai ) + '</span> · ' + esc( d.roman ) + '</p>' +
			'<h2>' + esc( d.name ) + '</h2>' +
			'<div class="kt-tags">' + ( d.likes ? '<span class="kt-tag">Uber Eats: ' + esc( d.likes ) + '</span>' : '' ) + ( d.portion ? '<span class="kt-tag kt-tag--line">' + esc( d.portion ) + '</span>' : '' ) + diets + '</div>' +
			'<p class="kt-dish__desc">' + esc( d.short ) + '</p>' + peanut +
			choiceHtml + spiceHtml + extrasHtml + sweetHtml + milkHtml +
			'<label class="kt-opt kt-opt--note">Allergies or requests<input type="text" name="note" maxlength="160" placeholder="e.g. no peanuts, sauce on the side"></label>' +
			'<details class="kt-dish__sheet"><summary>Ingredients &amp; allergens</summary><div><p><strong>Key ingredients:</strong> ' + esc( d.ingr.join( ', ' ) ) + '</p><p><strong>Allergens:</strong> ' + esc( d.allergens.length ? d.allergens.join( ', ' ) : 'none of the common ones' ) + '</p>' + ( d.veganNote ? '<p>' + esc( d.veganNote ) + '</p>' : '' ) + '<p class="kt-small">Our kitchen also handles peanuts, shellfish, egg, soy, sesame and fish sauce.</p></div></details>' +
			'<div class="kt-dish__buy"><div class="kt-qty"><button type="button" data-kt-qty="-1" aria-label="One less">−</button><output data-kt-qty-out>1</output><button type="button" data-kt-qty="1" aria-label="One more">+</button></div>' +
			'<button type="submit" class="wp-element-button kt-dish__add">Add to order · <span data-kt-dish-total></span></button></div>' +
			'<div class="kt-dish__links"><a class="kt-wa-order" data-kt-dish-wa href="#" target="_blank" rel="noopener">Instant WhatsApp order</a><a class="kt-link" href="' + esc( d.url ) + '">Full details →</a></div>' +
			'</div></form>';
		const form = body.querySelector( 'form' );
		const update = () => {
			const f = new FormData( form );
			state.choice = f.get( 'choice' ) || '';
			state.spice = Number( f.get( 'spice' ) || 0 );
			state.extras = f.getAll( 'extras' );
			state.sweet = f.get( 'sweet' ) || 'regular';
			state.milk = f.get( 'milk' ) && f.get( 'milk' ) !== 'regular' ? f.get( 'milk' ) : '';
			state.note = String( f.get( 'note' ) || '' ).trim();
			const t = dishTotal( state );
			body.querySelector( '[data-kt-dish-total]' ).textContent = fmt( t.total );
			body.querySelector( '[data-kt-qty-out]' ).textContent = state.qty;
			const opts = [];
			if ( state.spice ) opts.push( 'Spice ' + state.spice + '/5' );
			state.extras.forEach( ( k ) => opts.push( cfg.opts.extras[ k ][ 0 ] ) );
			if ( state.sweet !== 'regular' && f.get( 'sweet' ) ) opts.push( cfg.opts.sweet[ state.sweet ] );
			if ( state.milk ) opts.push( cfg.opts.milk[ state.milk ][ 0 ] );
			if ( state.note ) opts.push( 'Note: ' + state.note );
			body.querySelector( '[data-kt-dish-wa]' ).href = waUrl( [ 'Hi Khrung Thep, I\'d like to order (' + MODES[ getMode() ] + '):', '• ' + state.qty + ' × ' + d.name + ( t.choice ? ' (' + t.choice.label + ')' : '' ) + ' – ' + fmt( t.total ), ...( opts.length ? [ '   ' + opts.join( ' · ' ) ] : [] ), ...modeLines(), 'Name: ' ].join( '\n' ) );
			$$( '.kt-pills label, .kt-spice label, .kt-checks label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
		};
		form.addEventListener( 'change', update );
		form.addEventListener( 'input', update );
		form.addEventListener( 'click', ( e ) => {
			const q = e.target.closest( '[data-kt-qty]' );
			if ( q ) {
				state.qty = Math.max( 1, Math.min( 20, state.qty + Number( q.dataset.ktQty ) ) );
				update();
			}
			const ti = e.target.closest( '[data-kt-dish-img]' );
			const main = body.querySelector( '.kt-dish__main' );
			const video = body.querySelector( '[data-kt-dish-video]' );
			if ( ti ) {
				$$( 'img', main ).forEach( ( im, i ) => ( im.hidden = i !== Number( ti.dataset.ktDishImg ) ) );
				if ( video ) {
					video.hidden = true;
					video.pause();
				}
				$$( '.kt-dish__thumbs button', body ).forEach( ( b ) => b.classList.toggle( 'is-on', b === ti ) );
			}
			if ( e.target.closest( '[data-kt-dish-clip]' ) && video ) {
				$$( 'img', main ).forEach( ( im ) => ( im.hidden = true ) );
				video.hidden = false;
				video.play().catch( () => {} );
				$$( '.kt-dish__thumbs button', body ).forEach( ( b ) => b.classList.toggle( 'is-on', b.hasAttribute( 'data-kt-dish-clip' ) ) );
			}
		} );
		form.addEventListener( 'submit', async ( e ) => {
			e.preventDefault();
			const btn = form.querySelector( '.kt-dish__add' );
			btn.disabled = true;
			try {
				const kt = { spice: state.spice || undefined, extras: state.extras, sweet: state.sweet, milk: state.milk || 'regular', note: state.note };
				await addItem( state.choice || d.id, state.qty, kt );
				dlg.close();
				const t = dishTotal( state );
				toast( addedMsg( d.name + ( t.choice ? ' (' + t.choice.label + ')' : '' ), state.qty ) );
			} catch ( err ) {
				toast( esc( err.message || 'Could not add. Please try again.' ) );
			} finally {
				btn.disabled = false;
			}
		} );
		update();
		dlg.showModal();
		return true;
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-kt-dish]' );
		if ( ! b || e.ctrlKey || e.metaKey || e.shiftKey ) return;
		if ( openDish( b.dataset.ktDish ) ) e.preventDefault();
	} );
	if ( dlg ) dlg.addEventListener( 'close', () => $$( 'video', dlg ).forEach( ( v ) => v.pause() ) );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.kt-dialog' ) ) e.target.close();
	} );

	/* Menu hub: live filters --------------------------------------------- */
	function initMenu() {
		const root = document.querySelector( '[data-kt-menu]' );
		if ( ! root ) return;
		const cards = $$( '[data-kt-card]', root );
		const params = new URLSearchParams( location.search );
		const hash = location.hash.replace( '#', '' );
		const state = {
			q: params.get( 'q' ) || '',
			cat: params.get( 'cat' ) || ( $$( '[data-kt-cat="' + hash + '"]', root ).length ? hash : root.dataset.startCat || '' ),
			spice: params.get( 'spice' ) || '',
			diets: new Set( ( params.get( 'diet' ) || '' ).split( ',' ).filter( Boolean ) ),
			max: Number( params.get( 'max' ) ) || 2500,
			sort: '',
		};
		const q = root.querySelector( '[data-kt-q]' );
		const range = root.querySelector( '[data-kt-price]' );
		const priceLabel = root.querySelector( '[data-kt-price-label]' );
		const count = root.querySelector( '[data-kt-count]' );
		const empty = root.querySelector( '[data-kt-empty]' );
		const active = root.querySelector( '[data-kt-active]' );
		const more = root.querySelector( '[data-kt-more]' );
		q.value = state.q;
		range.value = state.max;
		if ( state.spice || state.diets.size || state.max < 2500 ) more.open = true;
		const matches = ( c ) => {
			const d = c.dataset;
			const tags = d.tags.split( ' ' );
			if ( state.cat && d.cat !== state.cat ) return false;
			if ( state.q && d.name.indexOf( state.q.toLowerCase().trim() ) === -1 ) return false;
			if ( state.max < 2500 && Number( d.price ) > state.max ) return false;
			for ( const t of state.diets ) {
				if ( t === 'no-peanuts' ? tags.indexOf( 'peanuts' ) > -1 : tags.indexOf( t ) === -1 ) return false;
			}
			if ( state.spice ) {
				// Dishes with the 1–5 chilli scale can be made at any heat; the rest by how they come.
				const heat = Number( d.heat );
				const s = Number( state.spice );
				if ( d.spice !== '1' && ! ( s === 1 ? heat <= 1 && [ 'starters', 'wok', 'curries', 'deals' ].indexOf( d.cat ) > -1 : heat === s ) ) return false;
			}
			return true;
		};
		// Home page: only the most-loved dishes until the visitor searches or filters.
		const previewMore = root.querySelector( '[data-kt-preview-more]' );
		const apply = () => {
			const preview = root.hasAttribute( 'data-kt-preview' ) && ! state.q && ! state.cat && ! state.spice && ! state.diets.size && state.max >= 2500 && ! state.showAll;
			root.classList.toggle( 'is-preview', preview );
			if ( previewMore ) previewMore.hidden = ! preview;
			let n = 0;
			cards.forEach( ( c ) => {
				const on = preview ? c.hasAttribute( 'data-featured' ) : matches( c );
				c.hidden = ! on;
				if ( on ) n++;
			} );
			$$( '[data-kt-sec]', root ).forEach( ( s ) => ( s.hidden = ! $$( '[data-kt-card]:not([hidden])', s ).length ) );
			// Sorting: inside each section.
			$$( '.kt-grid', root ).forEach( ( g ) => {
				const list = $$( '[data-kt-card]', g );
				const key = { popular: ( c ) => ( menu[ c.dataset.id ] && menu[ c.dataset.id ].likes ? 0 : 1 ) * 1000 + Number( c.dataset.order ), low: ( c ) => Number( c.dataset.price ), high: ( c ) => -Number( c.dataset.price ) }[ state.sort ] || ( ( c ) => Number( c.dataset.order ) );
				list.sort( ( a, b ) => key( a ) - key( b ) ).forEach( ( c ) => g.appendChild( c ) );
			} );
			count.textContent = preview ? 'Our ' + n + ' most-loved · search or filter to see all ' + cards.length : n + ( n === 1 ? ' dish' : ' dishes & drinks' ) + ( state.cat ? ' in ' + root.querySelector( '[data-kt-cat="' + state.cat + '"]' ).textContent : '' );
			empty.hidden = n > 0;
			$$( '[data-kt-cat]', root ).forEach( ( b ) => b.classList.toggle( 'is-on', ! preview && b.dataset.ktCat === state.cat ) );
			$$( '[data-kt-spice]', root ).forEach( ( b ) => b.setAttribute( 'aria-pressed', b.dataset.ktSpice === state.spice ? 'true' : 'false' ) );
			$$( '[data-kt-diet]', root ).forEach( ( b ) => b.setAttribute( 'aria-pressed', state.diets.has( b.dataset.ktDiet ) ? 'true' : 'false' ) );
			priceLabel.textContent = state.max >= 2500 ? 'Any price' : 'Up to ' + fmt( state.max );
			const nActive = ( state.spice ? 1 : 0 ) + state.diets.size + ( state.max < 2500 ? 1 : 0 );
			active.textContent = nActive ? nActive + ' on' : '';
			$$( '[data-kt-clear]', root ).forEach( ( b ) => ( b.hidden = ! ( nActive || state.q || state.cat ) && ! b.closest( '[data-kt-empty]' ) ) );
		};
		root.addEventListener( 'click', ( e ) => {
			const t = e.target.closest( '[data-kt-cat],[data-kt-spice],[data-kt-diet],[data-kt-clear]' );
			if ( ! t ) return;
			if ( t.hasAttribute( 'data-kt-cat' ) ) {
				state.cat = t.dataset.ktCat;
				if ( ! state.cat ) state.showAll = true; // "All" opens the whole menu, even on the home page
				if ( state.cat ) history.replaceState( null, '', '#' + state.cat );
			}
			if ( t.hasAttribute( 'data-kt-spice' ) ) state.spice = t.dataset.ktSpice;
			if ( t.hasAttribute( 'data-kt-diet' ) ) state.diets[ state.diets.has( t.dataset.ktDiet ) ? 'delete' : 'add' ]( t.dataset.ktDiet );
			if ( t.hasAttribute( 'data-kt-clear' ) ) {
				Object.assign( state, { q: '', cat: '', spice: '', max: 2500, showAll: false } );
				state.diets.clear();
				q.value = '';
				range.value = 2500;
			}
			apply();
		} );
		q.addEventListener( 'input', () => {
			state.q = q.value;
			apply();
		} );
		range.addEventListener( 'input', () => {
			state.max = Number( range.value );
			apply();
		} );
		root.querySelector( '[data-kt-sort]' ).addEventListener( 'change', ( e ) => {
			state.sort = e.target.value;
			apply();
		} );
		// The header search filters this menu live instead of reloading.
		$$( '[data-kt-search-form]' ).forEach( ( f ) => f.addEventListener( 'submit', ( e ) => {
			e.preventDefault();
			const fd = new FormData( f );
			state.q = String( fd.get( 'q' ) || '' );
			q.value = state.q;
			if ( fd.get( 'diet' ) ) state.diets = new Set( [ fd.get( 'diet' ) ] );
			apply();
			root.scrollIntoView( { behavior: 'smooth' } );
		} ) );
		apply();
		if ( state.cat || state.q || params.toString() ) setTimeout( () => root.scrollIntoView( { behavior: 'smooth' } ), 200 );
	}

	/* Card photo sliders: dots follow the swipe -------------------------- */
	function initSlides() {
		$$( '.kt-card__slides' ).forEach( ( s ) => {
			const dots = $$( 'i', s.parentNode.querySelector( '.kt-card__dots' ) || document.createElement( 'div' ) );
			if ( ! dots.length ) return;
			dots[ 0 ].classList.add( 'is-on' );
			s.addEventListener( 'scroll', () => {
				const i = Math.round( s.scrollLeft / s.clientWidth );
				dots.forEach( ( d, n ) => d.classList.toggle( 'is-on', n === i ) );
			}, { passive: true } );
		} );
	}

	/* Reservations, events, Tasting Club --------------------------------- */
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-kt-reserve]' );
		const d = document.getElementById( 'kt-reserve' );
		if ( ! a || ! d || ! d.showModal ) return;
		e.preventDefault();
		if ( document.getElementById( 'kt-dish' ) && document.getElementById( 'kt-dish' ).open ) document.getElementById( 'kt-dish' ).close();
		d.showModal();
	} );
	// Today: only times at least 30 minutes from now (Nairobi time).
	function trimTimes( form ) {
		const date = form.querySelector( 'select[name=date]' );
		const time = form.querySelector( 'select[name=time]' );
		if ( ! date || ! time ) return;
		const isToday = date.selectedIndex === 0;
		const n = nairobiNow();
		const [ h, m ] = n.hm.split( ':' ).map( Number );
		const soon = String( h + ( m >= 30 ? 1 : 0 ) ).padStart( 2, '0' ) + ':' + ( m >= 30 ? String( m - 30 ).padStart( 2, '0' ) : String( m + 30 ).padStart( 2, '0' ) );
		let first = null;
		Array.from( time.options ).forEach( ( o ) => {
			o.disabled = isToday && o.value < soon;
			o.hidden = o.disabled;
			if ( ! o.disabled && ! first ) first = o;
		} );
		// Nothing left today: start from tomorrow.
		if ( isToday && ! first && date.options.length > 1 ) {
			date.selectedIndex = 1;
			return trimTimes( form );
		}
		if ( time.selectedOptions[ 0 ] && time.selectedOptions[ 0 ].disabled && first ) time.value = first.value;
	}
	function peakNote( form ) {
		trimTimes( form );
		const note = form.querySelector( '[data-kt-peak]' );
		if ( ! note ) return;
		const date = form.querySelector( '[name=date]' );
		const time = form.querySelector( '[name=time]' );
		const day = date && date.value ? new Date( date.value + 'T12:00' ).getDay() : -1;
		note.hidden = ! ( ( day === 5 || day === 6 ) && time && time.value >= '18:00' );
	}
	function initRequests() {
		$$( '[data-kt-request]' ).forEach( ( form ) => {
			form.addEventListener( 'change', () => {
				peakNote( form );
				$$( '.kt-pills label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
			} );
			peakNote( form );
			$$( '.kt-pills label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
			form.addEventListener( 'submit', async ( e ) => {
				e.preventDefault();
				if ( ! form.reportValidity() ) return;
				const type = form.dataset.ktRequest;
				const fd = new FormData( form );
				const body = { type };
				fd.forEach( ( v, k ) => ( body[ k ] = v ) );
				const btn = form.querySelector( '[type=submit]' );
				const label = btn.textContent;
				btn.disabled = true;
				btn.textContent = 'Sending…';
				// Open WhatsApp inside the click (pop-up blockers), then point it at the message.
				// The static copy has no booking API: everything, Tasting Club included, goes to WhatsApp.
				const win = type === 'club' && ! window.KT_STATIC ? null : window.open( '', '_blank' );
				let ref, wa;
				try {
					if ( window.KT_STATIC ) throw new Error( 'static' );
					const res = await fetch( cfg.api + 'request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( body ) } );
					const j = await res.json();
					if ( ! res.ok ) throw Object.assign( new Error( j.message || 'error' ), { soft: res.status === 400 } );
					ref = j.ref;
					wa = j.wa;
				} catch ( err ) {
					if ( err.soft ) {
						if ( win ) win.close();
						toast( esc( err.message ) );
						btn.disabled = false;
						btn.textContent = label;
						return;
					}
					// No booking API (static copy): make a reference here and send it all on WhatsApp.
					ref = 'KT-' + { table: 'T', event: 'E', club: 'C' }[ type ] + String( Date.now() ).slice( -5 );
					const intro = { table: 'Hi Khrung Thep, I\'d like to reserve a table', event: 'Hi Khrung Thep, I\'d like a quote for an event', club: 'Hi Khrung Thep, please add me to the Tasting Club' }[ type ];
					const lines = [];
					fd.forEach( ( v, k ) => {
						if ( k !== 'website' && String( v ).trim() ) {
								const el = form.elements[ k ];
								lines.push( k.charAt( 0 ).toUpperCase() + k.slice( 1 ) + ': ' + ( el && el.tagName === 'SELECT' ? el.selectedOptions[ 0 ].text : v ) );
							}
					} );
					wa = waUrl( intro + ' (ref ' + ref + '):\n' + lines.join( '\n' ) );
				}
				btn.disabled = false;
				btn.textContent = label;
				if ( type === 'club' ) {
					if ( win ) win.location = wa;
					toast( '🍵 Welcome to the Tasting Club! We\'ll WhatsApp you our seasonal specials (ref ' + esc( ref ) + ').' );
					form.reset();
					return;
				}
				if ( win ) win.location = wa;
				else window.open( wa, '_blank' );
				toast( ( type === 'table' ? '✓ Table request ' : '✓ Event request ' ) + '<strong>' + esc( ref ) + '</strong> sent. We confirm on WhatsApp shortly.' );
				const dlgR = form.closest( 'dialog' );
				if ( dlgR ) dlgR.close();
				form.reset();
				peakNote( form );
			} );
		} );
	}

	/* Copy the location ----------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-kt-copy-loc]' );
		if ( ! b ) return;
		e.preventDefault();
		const text = 'Khrung Thep – Thai Restaurant & Matcha Cafe, ' + cfg.address + '\n' + cfg.maps;
		try {
			await navigator.clipboard.writeText( text );
			toast( '📍 Location copied. Paste it to your driver or friends.' );
		} catch ( err ) {
			window.prompt( 'Copy our location:', text );
		}
	} );

	/* Open now, and the day's offer in the top bar ------------------------- */
	function nairobiNow() {
		const now = new Date( Date.now() + ( new Date().getTimezoneOffset() + 180 ) * 60000 );
		return { day: now.getDay(), hm: String( now.getHours() ).padStart( 2, '0' ) + ':' + String( now.getMinutes() ).padStart( 2, '0' ) };
	}
	function initClock() {
		const n = nairobiNow();
		const open = n.hm >= cfg.open && n.hm < cfg.close;
		const h12 = ( hm ) => {
			const [ h, m ] = hm.split( ':' ).map( Number );
			return ( h % 12 || 12 ) + ( m ? ':' + String( m ).padStart( 2, '0' ) : '' ) + ( h < 12 ? ' am' : ' pm' );
		};
		$$( '[data-kt-open]' ).forEach( ( el ) => {
			el.classList.toggle( 'is-open', open );
			el.textContent = open ? 'Open now · until ' + h12( cfg.close ) : 'Closed now · opens ' + ( n.hm >= cfg.close ? 'tomorrow ' : '' ) + h12( cfg.open );
		} );
		$$( '[data-kt-promo]' ).forEach( ( el ) => {
			const msg = n.day === 5 ? '🎉 It\'s Thai Friday: 10% off everything with code <strong>THAIFRIDAY</strong>' : n.day >= 1 && n.day <= 4 ? '🍱 Corporate Lunch: Thai fried rice + juice for <strong>KSh 1,000</strong>, Mon–Thu' : '🌙 Weekend nights in the garden: <a href="/reservations/" data-kt-reserve>reserve your table</a>';
			el.innerHTML = msg;
		} );
	}

	/* Product page: option buttons, live option price, WhatsApp ------------ */
	function initPdp() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.ktSw ) return;
			sel.dataset.ktSw = '1';
			const wrap = document.createElement( 'div' );
			wrap.className = 'kt-pills kt-sw';
			wrap.setAttribute( 'role', 'radiogroup' );
			const vars = ( () => {
				try {
					return JSON.parse( sel.closest( 'form' ).dataset.product_variations || '[]' );
				} catch ( e ) {
					return [];
				}
			} )();
			wrap.innerHTML = Array.from( sel.options ).filter( ( o ) => o.value ).map( ( o ) => {
				const v = vars.find( ( x ) => Object.values( x.attributes || {} ).indexOf( o.value ) > -1 );
				return '<button type="button" role="radio" data-v="' + esc( o.value ) + '"><span>' + esc( o.text ) + '</span>' + ( v ? '<small>' + fmt( v.display_price ) + '</small>' : '' ) + '</button>';
			} ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'kt-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				b.classList.toggle( 'is-on', b.dataset.v === sel.value );
				b.setAttribute( 'aria-checked', b.dataset.v === sel.value ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
			} );
			paint();
		} );
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
		$$( '[data-kt-pdp-opts]' ).forEach( ( box ) => {
			if ( box.dataset.ktInit ) return;
			box.dataset.ktInit = '1';
			let out = box.querySelector( '.kt-opt-cost' );
			if ( ! out ) {
				out = document.createElement( 'p' );
				out.className = 'kt-opt-cost';
				box.appendChild( out );
			}
			const form = box.closest( 'form' );
			const wa = document.querySelector( '[data-kt-wa-pdp]' );
			const upd = () => {
				let add = 0;
				$$( 'input[data-kt-cost]:checked', box ).forEach( ( i ) => ( add += Number( i.dataset.ktCost ) ) );
				out.textContent = add ? 'Your options add ' + fmt( add ) + ' per item.' : '';
				$$( '.kt-pills label, .kt-spice label, .kt-checks label', box ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				if ( wa && form ) {
					const picked = [];
					$$( 'select[name^="attribute_"]', form ).forEach( ( s ) => s.value && picked.push( s.options[ s.selectedIndex ].text ) );
					const sp = box.querySelector( '[name="kt[spice]"]:checked' );
					if ( sp ) picked.push( 'Spice ' + sp.value + '/5' );
					$$( 'input[type=checkbox]:checked, [name="kt[sweet]"]:checked, [name="kt[milk]"]:checked', box ).forEach( ( i ) => i.value !== 'regular' && picked.push( i.closest( 'label' ).querySelector( 'span' ).textContent ) );
					const note = box.querySelector( '[name="kt[note]"]' );
					if ( note && note.value.trim() ) picked.push( 'Note: ' + note.value.trim() );
					wa.href = waUrl( [ 'Hi Khrung Thep, I\'d like to order (' + MODES[ getMode() ] + '):', '• 1 × ' + wa.dataset.ktWaPdp + ( picked.length ? ' (' + picked.join( ', ' ) + ')' : '' ), ...modeLines(), 'Name: ' ].join( '\n' ) );
				}
			};
			( form || box ).addEventListener( 'change', upd );
			box.addEventListener( 'input', upd );
			upd();
		} );
	}

	// The sticky header slides up by the announcement bar's height, whatever it wraps to.
	function measureAnnounce() {
		const a = document.querySelector( '.kt-announce' );
		if ( a ) document.documentElement.style.setProperty( '--kt-ann', a.offsetHeight + 'px' );
	}

	// Header menu: underline the page you're on.
	function markNav() {
		const here = location.pathname;
		const home = new URL( cfg.home || '/', location.href ).pathname;
		$$( '.kt-nav a.wp-block-navigation-item__content' ).forEach( ( a ) => {
			const path = new URL( a.href, location.href ).pathname;
			if ( path === home ? here === home : here.startsWith( path ) ) a.setAttribute( 'aria-current', 'page' );
		} );
	}

	function init() {
		markNav();
		measureAnnounce();
		window.addEventListener( 'resize', measureAnnounce );
		window.addEventListener( 'load', measureAnnounce );
		paintMode();
		initMenu();
		initSlides();
		initRequests();
		initClock();
		initPdp();
		new MutationObserver( () => initPdp() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
